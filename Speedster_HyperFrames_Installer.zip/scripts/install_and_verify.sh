#!/usr/bin/env bash
set -euo pipefail

# Install in a network-enabled Linux environment (GitHub Codespaces or GitHub Actions).
# Uses only published HyperFrames package; doesn't install into ChatGPT.
if ! command -v node >/dev/null; then echo 'Node 22+ is required'; exit 1; fi
node -e 'if(+process.versions.node.split(".")[0]<22){process.exit(1)}'
if ! command -v ffmpeg >/dev/null; then echo 'FFmpeg is required'; exit 1; fi

echo 'Installing official HyperFrames CLI from npm...'
npm install -g hyperframes@latest

echo 'CLI verification:'
hyperframes --version || hyperframes info
hyperframes doctor || echo 'Doctor flagged dependencies: check browser install with hyperframes browser'

echo 'Validate smoke composition:'
hyperframes lint ./smoke

echo 'Render smoke MP4:'
mkdir -p renders
( cd smoke && hyperframes render --output ../renders/hyperframes-smoke.mp4 --fps 15 --quality draft )
if [ ! -s renders/hyperframes-smoke.mp4 ]; then echo 'Render produced no MP4'; exit 2; fi
ffprobe -v error -show_entries format=duration,size -of default=noprint_wrappers=1 renders/hyperframes-smoke.mp4
echo 'SUCCESS: Official HyperFrames CLI installed and rendered renders/hyperframes-smoke.mp4'
