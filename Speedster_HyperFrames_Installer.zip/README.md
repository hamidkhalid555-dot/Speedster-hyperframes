# Speedster HyperFrames Installation Package

**Status: prepared, not installed in ChatGPT.** This is an install-and-test kit for an internet-enabled Node 22+ environment such as GitHub Codespaces. It does not contain the HyperFrames npm package or any user footage.

## Fast installation with GitHub Codespaces (from iPhone)

1. On github.com, create a **private** repository named `speedster-hyperframes`.
2. Upload **this entire ZIP as one file** to the repository through **Add file → Upload files**. Commit it; you don't have to extract it on your phone.
3. Open **Code → Codespaces → Create codespace on main**. On first run the repository contains just this ZIP, so install from the built-in terminal:

```bash
unzip Speedster_HyperFrames_Installer.zip
sudo apt-get update -qq && sudo apt-get install -y ffmpeg chromium
bash scripts/install_and_verify.sh
```

4. If the script completes, the Codespace now has the official HyperFrames CLI, and a real HyperFrames-rendered `renders/hyperframes-smoke.mp4` verifies the installation.
5. For a durable GitHub Actions workflow, commit the extracted project: `git add . && git commit -m "Add HyperFrames runner" && git push`. Then open **Actions → Install and test HyperFrames → Run workflow**.
6. Later add only original user-owned factory video clips to `Speedster_Starter/assets`, validate the composition, and render the first real Speedster reel.

**Important:** GitHub's default Codespace may already include Node/FFmpeg; the install script checks them. Codespaces/Actions may incur usage charges. This environment could not install the CLI due to blocked outbound DNS to npm; execution from a Codespace is a separate install that must succeed independently.

## Alternative: GitHub Actions (no browser terminal)
Commit the files and open **Actions → Install and test HyperFrames → Run workflow**. The resulting MP4 appears under the workflow run's Artifacts section. GitHub Codespaces/Actions usage may incur charges or free-minute limits according to your GitHub account.

## CLI installation command
```
npm install -g hyperframes
hyperframes doctor
```
Official docs: https://hyperframes.heygen.com/quickstart and https://github.com/heygen-com/hyperframes.

## Security and production requirements
- All factory/garment shots must come from actual Speedster user-supplied media.
- Never generate fictitious products, workers or completed orders.
- Human approval before publishing. No paid generation or campaign changes in installation workflow.
- MOQ 30 pieces; 14-day **production** turnaround after payment (excludes shipping).
- The provided `Speedster_Starter` is an editable first pass; real footage must be supplied and its final render tested.
- Neither a successful GitHub Actions install nor Codespaces installation makes HyperFrames available as a permanent ChatGPT plugin. It runs where installed.
