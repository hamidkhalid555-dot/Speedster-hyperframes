# Speedster — HyperFrames rendering setup

This is an **installer and smoke test**, not an existing completed installation. It contains no genuine Speedster footage and does not install a permanent ChatGPT plugin.

## Option A: ChatGPT GitHub connector (best when access is granted)

Grant the ChatGPT/OpenAI GitHub integration access to **hamidkhalid555-dot/Speedster-hyperframes** through https://github.com/settings/installations. It must have permission to write **repository contents**, and GitHub Actions workflow modifications if required by GitHub policy. Once enabled, the assistant can push these text files directly. The user still triggers the workflow in GitHub.

## Option B: iPhone GitHub Codespaces (no ChatGPT connector required)

1. Download `Speedster_HyperFrames_Installer.zip` and upload the ZIP using **Add file → Upload files** on your GitHub repository.
2. Open **Code → Codespaces → Create codespace on main**. If the repository is completely empty, first commit the ZIP or a README.
3. In the Codespaces terminal run:

```bash
unzip -o Speedster_HyperFrames_Installer.zip
sudo apt-get update -qq && sudo apt-get install -y ffmpeg chromium
bash scripts/install_and_verify.sh
```

This installs the official HyperFrames CLI inside that Codespace, validates a project, and tries to produce a two-second **diagnostic-only** MP4 in `renders/hyperframes-smoke.mp4`. The first run may download Node packages and browser dependencies; it must have network access. Codespaces usage may incur charges.

4. If successful, extract and commit only the source files to enable GitHub Actions:

```bash
git add README.md scripts/ smoke/ .github/ .devcontainer/ Speedster_Starter/ .gitignore
git commit -m "Install Speedster HyperFrames renderer"
git push
```

5. Use **Actions → Install and test HyperFrames → Run workflow**. A successful run exports the diagnostic MP4 under **Artifacts**. Actions runner installations are temporary; Codespaces is the persistent development environment. GitHub Actions usage may incur charges.

## What this does **not** do

- It does not connect the user’s personal iPhone to a local renderer.
- It does not automatically upload, edit, render, or publish Speedster factory footage.
- It does not generate fake factory/product images, footage, or testimonials.
- It does not install a HyperFrames ChatGPT plugin; the renderer runs in Codespaces/Actions.
- No Higgsfield credits or ad spend are used by this setup.

## Source

Official: https://github.com/heygen-com/hyperframes

Only use actual original Speedster factory/product video when building reels. 30-piece MOQ, 14-day production turnaround after payment (not delivery). Obtain approval before posting.
