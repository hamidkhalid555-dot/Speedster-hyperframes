Add the five genuine Speedster video clips referenced by `../index.html`, or edit the HTML paths. The first version is a template, NOT a video. No synthetic factory footage permitted.
