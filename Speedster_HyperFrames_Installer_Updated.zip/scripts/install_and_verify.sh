#!/usr/bin/env bash
set -Eeuo pipefail

# Run from repository root in a network-enabled GitHub Codespace or Actions runner.
cd "$(dirname "${BASH_SOURCE[0]}")/.."

command -v node >/dev/null || { echo 'Node.js 22+ is required'; exit 1; }
node -e 'if (Number(process.versions.node.split(".")[0]) < 22) process.exit(1)'
command -v npm >/dev/null || { echo 'npm is required'; exit 1; }
command -v ffmpeg >/dev/null || { echo 'FFmpeg is required'; exit 1; }
command -v ffprobe >/dev/null || { echo 'ffprobe is required'; exit 1; }

printf '\n=== Installing official HyperFrames CLI ===\n'
# Installation is isolated under .tools rather than changing the host globally.
npm install --prefix .tools --no-audit --no-fund hyperframes@latest
HF="$PWD/.tools/node_modules/.bin/hyperframes"
test -x "$HF" || { echo 'HyperFrames binary was not installed'; exit 1; }
"$HF" --version

printf '\n=== Checking environment ===\n'
"$HF" doctor --json || true

printf '\n=== Creating an official HyperFrames project ===\n'
PROJECT="$PWD/build/speedster-install-test"
mkdir -p "$PWD/build"
"$HF" init "$PROJECT" --non-interactive --example=blank

# Replace the blank composition with a transparent, NON-MANUFACTURING diagnostic.
# This contains no user footage, client information, or AI-manufactured proof.
cp smoke/index.html "$PROJECT/index.html"

printf '\n=== Checking HyperFrames composition ===\n'
(cd "$PROJECT" && "$HF" check)

printf '\n=== Rendering a short test MP4 ===\n'
mkdir -p "$PWD/renders"
(cd "$PROJECT" && "$HF" render --output "$PWD/renders/hyperframes-smoke.mp4" --quality draft)

test -s renders/hyperframes-smoke.mp4 || { echo 'No MP4 output produced'; exit 2; }
ffprobe -v error -show_entries format=duration,size -of default=noprint_wrappers=1 renders/hyperframes-smoke.mp4
printf '\nSUCCESS: official HyperFrames CLI rendered an MP4.\n'
